# Iowa City College Student Guide
Fictional MKTG:4400 educational website.

Before publishing, replace YOUR-USERNAME in sitemap.xml and robots.txt with your GitHub username (and change the repository path if needed).
